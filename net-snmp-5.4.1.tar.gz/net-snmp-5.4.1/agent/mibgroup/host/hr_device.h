/*
 *  Host Resources MIB - device group interface - hr_device.h
 *
 */
#ifndef _MIBGROUP_HRDEVICE_H
#define _MIBGROUP_HRDEVICE_H

extern void     init_hr_device(void);
extern FindVarMethod var_hrdevice;

#endif                          /* _MIBGROUP_HRDEVICE_H */
