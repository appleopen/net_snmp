/* freebsd6 is a superset of freebsd5 */
#include "freebsd5.h"
#define freebsd5 freebsd5
